EkmanLib

**Library for Calculate Ekman Mass Transport and Ekman Pumping Velocity**

The library can calculate Wind Data from ERA5, CCMP, etc.

Konfersi Indonesia
